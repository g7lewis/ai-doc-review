import { useState } from 'react';
import Link from 'next/link';

export default function ResultsPage() {
  // In a real implementation, we would fetch results from an API
  // This is a mock implementation for the MVP
  const [activeTab, setActiveTab] = useState('discrepancies');
  
  const mockResults = {
    documentName: "Groundwater Monitoring Report Q1 2025.pdf",
    uploadDate: "April 16, 2025",
    analysisDate: "April 16, 2025",
    status: "Completed",
    discrepancies: [
      {
        id: 1,
        type: "Numerical Discrepancy",
        description: "The text on page 12 states the pH level as 7.2, but Table 3 shows it as 7.5.",
        location: "Page 12, Paragraph 3 & Table 3",
        severity: "Medium",
      },
      {
        id: 2,
        type: "Numerical Discrepancy",
        description: "The groundwater level is reported as 45.3 feet in the text on page 8, but Figure 2 shows it as 45.8 feet.",
        location: "Page 8, Section 4.2 & Figure 2",
        severity: "Low",
      },
      {
        id: 3,
        type: "Numerical Discrepancy",
        description: "The concentration of dissolved solids is listed as 320 mg/L in the executive summary, but Table 5 shows 350 mg/L.",
        location: "Page 2, Executive Summary & Page 18, Table 5",
        severity: "High",
      },
    ],
    regulatoryGaps: [
      {
        id: 1,
        regulation: "EPA Groundwater Monitoring Requirements",
        description: "The report is missing required information on sampling methodology as specified in Section 3.2 of EPA guidelines.",
        recommendation: "Add a detailed description of the sampling methodology used, including equipment and procedures.",
        severity: "High",
      },
      {
        id: 2,
        regulation: "State Environmental Quality Standards",
        description: "The report does not address the new requirement for PFAS monitoring that became effective January 2025.",
        recommendation: "Include PFAS monitoring results or provide justification for exclusion.",
        severity: "Medium",
      },
    ],
    completenessIssues: [
      {
        id: 1,
        description: "The Quality Assurance section is incomplete, missing information on laboratory certifications.",
        recommendation: "Add laboratory certification details to the Quality Assurance section.",
        severity: "Medium",
      },
      {
        id: 2,
        description: "Appendix B referenced in the text is not included in the document.",
        recommendation: "Include Appendix B with the referenced data tables.",
        severity: "Low",
      },
    ]
  };

  const renderSeverityBadge = (severity: string) => {
    const colors = {
      'Low': 'bg-blue-100 text-blue-800',
      'Medium': 'bg-yellow-100 text-yellow-800',
      'High': 'bg-red-100 text-red-800',
    };
    
    return (
      <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${colors[severity as keyof typeof colors]}`}>
        {severity}
      </span>
    );
  };

  return (
    <div className="py-10">
      <header>
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-bold leading-tight tracking-tight text-gray-900">Analysis Results</h1>
        </div>
      </header>
      <main>
        <div className="mx-auto max-w-7xl sm:px-6 lg:px-8">
          <div className="px-4 py-8 sm:px-0">
            <div className="overflow-hidden bg-white shadow sm:rounded-lg">
              <div className="px-4 py-5 sm:px-6">
                <h3 className="text-lg font-medium leading-6 text-gray-900">Document Information</h3>
                <p className="mt-1 max-w-2xl text-sm text-gray-500">Details and analysis results.</p>
              </div>
              <div className="border-t border-gray-200 px-4 py-5 sm:p-0">
                <dl className="sm:divide-y sm:divide-gray-200">
                  <div className="py-4 sm:grid sm:grid-cols-3 sm:gap-4 sm:py-5 sm:px-6">
                    <dt className="text-sm font-medium text-gray-500">Document name</dt>
                    <dd className="mt-1 text-sm text-gray-900 sm:col-span-2 sm:mt-0">{mockResults.documentName}</dd>
                  </div>
                  <div className="py-4 sm:grid sm:grid-cols-3 sm:gap-4 sm:py-5 sm:px-6">
                    <dt className="text-sm font-medium text-gray-500">Upload date</dt>
                    <dd className="mt-1 text-sm text-gray-900 sm:col-span-2 sm:mt-0">{mockResults.uploadDate}</dd>
                  </div>
                  <div className="py-4 sm:grid sm:grid-cols-3 sm:gap-4 sm:py-5 sm:px-6">
                    <dt className="text-sm font-medium text-gray-500">Analysis date</dt>
                    <dd className="mt-1 text-sm text-gray-900 sm:col-span-2 sm:mt-0">{mockResults.analysisDate}</dd>
                  </div>
                  <div className="py-4 sm:grid sm:grid-cols-3 sm:gap-4 sm:py-5 sm:px-6">
                    <dt className="text-sm font-medium text-gray-500">Status</dt>
                    <dd className="mt-1 text-sm text-gray-900 sm:col-span-2 sm:mt-0">
                      <span className="inline-flex items-center rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-medium text-green-800">
                        {mockResults.status}
                      </span>
                    </dd>
                  </div>
                </dl>
              </div>
            </div>

            <div className="mt-8">
              <div className="sm:hidden">
                <label htmlFor="tabs" className="sr-only">
                  Select a tab
                </label>
                <select
                  id="tabs"
                  name="tabs"
                  className="block w-full rounded-md border-gray-300 focus:border-indigo-500 focus:ring-indigo-500"
                  value={activeTab}
                  onChange={(e) => setActiveTab(e.target.value)}
                >
                  <option value="discrepancies">Numerical Discrepancies</option>
                  <option value="regulatory">Regulatory Gaps</option>
                  <option value="completeness">Completeness Issues</option>
                </select>
              </div>
              <div className="hidden sm:block">
                <div className="border-b border-gray-200">
                  <nav className="-mb-px flex space-x-8" aria-label="Tabs">
                    <button
                      onClick={() => setActiveTab('discrepancies')}
                      className={`${
                        activeTab === 'discrepancies'
                          ? 'border-indigo-500 text-indigo-600'
                          : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
                      } whitespace-nowrap border-b-2 py-4 px-1 text-sm font-medium`}
                    >
                      Numerical Discrepancies
                      <span className={`${
                        activeTab === 'discrepancies' ? 'bg-indigo-100 text-indigo-600' : 'bg-gray-100 text-gray-900'
                      } ml-3 hidden rounded-full py-0.5 px-2.5 text-xs font-medium md:inline-block`}>
                        {mockResults.discrepancies.length}
                      </span>
                    </button>
                    <button
                      onClick={() => setActiveTab('regulatory')}
                      className={`${
                        activeTab === 'regulatory'
                          ? 'border-indigo-500 text-indigo-600'
                          : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
                      } whitespace-nowrap border-b-2 py-4 px-1 text-sm font-medium`}
                    >
                      Regulatory Gaps
                      <span className={`${
                        activeTab === 'regulatory' ? 'bg-indigo-100 text-indigo-600' : 'bg-gray-100 text-gray-900'
                      } ml-3 hidden rounded-full py-0.5 px-2.5 text-xs font-medium md:inline-block`}>
                        {mockResults.regulatoryGaps.length}
                      </span>
                    </button>
                    <button
                      onClick={() => setActiveTab('completeness')}
                      className={`${
                        activeTab === 'completeness'
                          ? 'border-indigo-500 text-indigo-600'
                          : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
                      } whitespace-nowrap border-b-2 py-4 px-1 text-sm font-medium`}
                    >
                      Completeness Issues
                      <span className={`${
                        activeTab === 'completeness' ? 'bg-indigo-100 text-indigo-600' : 'bg-gray-100 text-gray-900'
                      } ml-3 hidden rounded-full py-0.5 px-2.5 text-xs font-medium md:inline-block`}>
                        {mockResults.completenessIssues.length}
                      </span>
                    </button>
                  </nav>
                </div>
              </div>

              <div className="mt-8">
                {activeTab === 'discrepancies' && (
                  <div>
                    <h3 className="text-lg font-medium text-gray-900">Numerical Discrepancies</h3>
                    <p className="mt-1 text-sm text-gray-500">
                      Inconsistencies between numerical values in text and tables.
                    </p>
                    <ul role="list" className="mt-6 divide-y divide-gray-200">
                      {mockResults.discrepancies.map((item) => (
                        <li key={item.id} className="py-4">
                          <div className="flex items-start space-x-4">
                            <div className="flex-shrink-0">
                              <svg className="h-6 w-6 text-yellow-500" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" />
                              </svg>
                            </div>
                            <div className="min-w-0 flex-1">
                              <div className="text-sm font-medium text-gray-900">{item.type}</div>
                              <div className="mt-1 text-sm text-gray-600">{item.description}</div>
                              <div className="mt-2 flex items-center space-x-4">
                                <div className="text-xs text-gray-500">
                                  <span className="font-medium text-gray-900">Location:</span> {item.location}
                                </div>
                                <div>{renderSeverityBadge(item.severity)}</div>
                              </div>
                            </div>
                          </div>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {activeTab === 'regulatory' && (
                  <div>
                    <h3 className="text-lg font-medium text-gray-900">Regulatory Gaps</h3>
                    <p className="mt-1 text-sm text-gray-500">
                      Areas where the document may not meet regulatory requirements.
                    </p>
                    <ul role="list" className="mt-6 divide-y divide-gray-200">
                      {mockResults.regulatoryGaps.map((item) => (
                        <li key={item.id} className="py-4">
                          <div className="flex items-start space-x-4">
                            <div className="flex-shrink-0">
                              <svg className="h-6 w-6 text-red-500" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z" />
                              </svg>
                            </div>
                            <div className="min-w-0 flex-1">
                              <div className="text-sm font-medium text-gray-900">{item.regulation}</div>
                              <div className="mt-1 text-sm text-gray-600">{item.description}</div>
                              <div className="mt-2 text-sm text-gray-600">
                                <span className="font-medium text-gray-900">Recommendation:</span> {item.recommendation}
                              </div>
                              <div className="mt-2">{renderSeverityBadge(item.severity)}</div>
                            </div>
                          </div>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {activeTab === 'completeness' && (
                  <div>
                    <h3 className="text-lg font-medium text-gray-900">Completeness Issues</h3>
                    <p className="mt-1 text-sm text-gray-500">
                      Missing or incomplete sections in the document.
                    </p>
                    <ul role="list" className="mt-6 divide-y divide-gray-200">
                      {mockResults.completenessIssues.map((item) => (
                        <li key={item.id} className="py-4">
                          <div className="flex items-start space-x-4">
                            <div className="flex-shrink-0">
                              <svg className="h-6 w-6 text-blue-500" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M11.25 11.25l.041-.02a.75.75 0 011.063.852l-.708 2.836a.75.75 0 001.063.853l.041-.021M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9-3.75h.008v.008H12V8.25z" />
                              </svg>
                            </div>
                            <div className="min-w-0 flex-1">
                              <div className="mt-1 text-sm text-gray-600">{item.description}</div>
                              <div className="mt-2 text-sm text-gray-600">
                                <span className="font-medium text-gray-900">Recommendation:</span> {item.recommendation}
                              </div>
                              <div className="mt-2">{renderSeverityBadge(item.severity)}</div>
                            </div>
                          </div>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              <div className="mt-8 flex justify-end">
                <Link
                  href="/dashboard"
                  className="rounded-md bg-white py-2 px-4 text-sm font-medium text-gray-700 shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50"
                >
                  Back to Dashboard
                </Link>
                <button
                  type="button"
                  className="ml-3 inline-flex items-center rounded-md bg-indigo-600 py-2 px-4 text-sm font-medium text-white shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
                >
                  Download Report
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
