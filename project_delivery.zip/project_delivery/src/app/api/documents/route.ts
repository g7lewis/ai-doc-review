import { NextRequest, NextResponse } from 'next/server';

// This is a mock API endpoint for fetching documents
// In a real implementation, this would fetch documents from a database

export async function GET(request: NextRequest) {
  try {
    // In a real implementation, we would fetch documents from a database
    // For the MVP, we'll return mock data
    
    const mockDocuments = [
      {
        id: "doc-001",
        name: "Groundwater Monitoring Report Q1 2025.pdf",
        type: "Environmental Report",
        uploadDate: "April 16, 2025",
        status: "Analyzed",
        issues: 7,
      },
      {
        id: "doc-002",
        name: "Site Assessment Technical Specification.docx",
        type: "Technical Specification",
        uploadDate: "April 15, 2025",
        status: "Analyzed",
        issues: 3,
      },
      {
        id: "doc-003",
        name: "Environmental Compliance Summary 2024.xlsx",
        type: "Business Document",
        uploadDate: "April 14, 2025",
        status: "Analyzed",
        issues: 5,
      },
      {
        id: "doc-004",
        name: "Remediation Plan Draft.pdf",
        type: "Environmental Report",
        uploadDate: "April 13, 2025",
        status: "Analyzed",
        issues: 12,
      },
    ];
    
    return NextResponse.json(mockDocuments);
    
  } catch (error) {
    console.error('Error fetching documents:', error);
    return NextResponse.json(
      { error: 'Error fetching documents' },
      { status: 500 }
    );
  }
}
