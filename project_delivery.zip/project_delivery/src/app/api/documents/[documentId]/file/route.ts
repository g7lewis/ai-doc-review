import { createReadStream } from 'fs';
import { join } from 'path';
import { NextRequest, NextResponse } from 'next/server';

// This endpoint serves document files from the uploads directory
export async function GET(
  request: NextRequest,
  { params }: { params: { documentId: string } }
) {
  try {
    const documentId = params.documentId;
    
    // In a real implementation, we would fetch the document metadata from a database
    // to get the actual filename and verify access permissions
    
    // For the MVP, we'll assume the document exists with a specific format
    // Format: {documentId}-{originalFilename}
    // We'll use a mock filename for demonstration
    const mockFilename = `${documentId}-Groundwater Monitoring Report Q1 2025.pdf`;
    const filePath = join(process.cwd(), 'uploads', mockFilename);
    
    // Create a readable stream for the file
    try {
      const fileStream = createReadStream(filePath);
      
      // Set appropriate headers based on file type
      // For simplicity, we're assuming PDF in this example
      const headers = new Headers();
      headers.set('Content-Type', 'application/pdf');
      headers.set('Content-Disposition', `inline; filename="${mockFilename.split('-')[1]}"`);
      
      return new NextResponse(fileStream as any, {
        headers,
      });
    } catch (error) {
      console.error('Error reading file:', error);
      return NextResponse.json(
        { error: 'Document not found' },
        { status: 404 }
      );
    }
  } catch (error) {
    console.error('Error serving document:', error);
    return NextResponse.json(
      { error: 'Error serving document' },
      { status: 500 }
    );
  }
}
