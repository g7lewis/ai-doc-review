import { NextRequest, NextResponse } from 'next/server';

// This is a mock API endpoint for document metadata
// In a real implementation, this would fetch document metadata from a database

export async function GET(
  request: NextRequest,
  { params }: { params: { documentId: string } }
) {
  try {
    const documentId = params.documentId;
    
    // In a real implementation, we would fetch the document metadata from a database
    // For the MVP, we'll return mock data
    
    const mockDocument = {
      id: documentId,
      name: "Groundwater Monitoring Report Q1 2025.pdf",
      type: "Environmental Report",
      uploadDate: "April 16, 2025",
      analysisDate: "April 16, 2025",
      status: "Analyzed",
      issues: 7,
      size: "3.2 MB",
      pages: 42,
      author: "Environmental Monitoring Team",
      lastModified: "April 10, 2025",
    };
    
    return NextResponse.json(mockDocument);
    
  } catch (error) {
    console.error('Error fetching document metadata:', error);
    return NextResponse.json(
      { error: 'Error fetching document metadata' },
      { status: 500 }
    );
  }
}
