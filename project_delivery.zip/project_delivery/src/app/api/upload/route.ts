import { NextRequest, NextResponse } from 'next/server';
import { writeFile } from 'fs/promises';
import { join } from 'path';
import { v4 as uuidv4 } from 'uuid';

// Define allowed file types
const allowedTypes = [
  'application/pdf',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'application/msword',
  'application/vnd.ms-excel'
];

// Maximum file size (20MB)
const maxSize = 20 * 1024 * 1024;

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File;
    const documentType = formData.get('documentType') as string;
    const analysisOptions = {
      numericalDiscrepancy: formData.get('numericalDiscrepancy') === 'true',
      regulatoryCompliance: formData.get('regulatoryCompliance') === 'true',
      contentCompleteness: formData.get('contentCompleteness') === 'true',
    };

    // Validate file exists
    if (!file) {
      return NextResponse.json(
        { error: 'No file provided' },
        { status: 400 }
      );
    }

    // Validate file type
    if (!allowedTypes.includes(file.type)) {
      return NextResponse.json(
        { error: 'File type not supported. Please upload a PDF, Word, or Excel document.' },
        { status: 400 }
      );
    }

    // Validate file size
    if (file.size > maxSize) {
      return NextResponse.json(
        { error: 'File is too large. Maximum size is 20MB.' },
        { status: 400 }
      );
    }

    // Create unique ID for the document
    const documentId = uuidv4();
    
    // Create uploads directory if it doesn't exist
    const uploadsDir = join(process.cwd(), 'uploads');
    
    try {
      // Convert file to buffer
      const bytes = await file.arrayBuffer();
      const buffer = Buffer.from(bytes);
      
      // Save file with unique name
      const fileName = `${documentId}-${file.name}`;
      const filePath = join(uploadsDir, fileName);
      await writeFile(filePath, buffer);
      
      // Store document metadata (in a real implementation, this would go to a database)
      const documentMetadata = {
        id: documentId,
        name: file.name,
        type: documentType,
        path: filePath,
        uploadDate: new Date().toISOString(),
        analysisOptions,
        status: 'Uploaded',
      };
      
      // In a real implementation, we would trigger the document analysis process here
      // For the MVP, we'll simulate this by returning a success response
      
      return NextResponse.json({
        success: true,
        documentId,
        message: 'Document uploaded successfully and queued for analysis',
        metadata: documentMetadata
      });
      
    } catch (error) {
      console.error('Error saving file:', error);
      return NextResponse.json(
        { error: 'Error saving file' },
        { status: 500 }
      );
    }
  } catch (error) {
    console.error('Error processing upload:', error);
    return NextResponse.json(
      { error: 'Error processing upload' },
      { status: 500 }
    );
  }
}
