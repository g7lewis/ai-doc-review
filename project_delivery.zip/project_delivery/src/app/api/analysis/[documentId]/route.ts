import { NextRequest, NextResponse } from 'next/server';

// This is a mock API endpoint for document analysis results
// In a real implementation, this would fetch results from a database

export async function GET(
  request: NextRequest,
  { params }: { params: { documentId: string } }
) {
  try {
    const documentId = params.documentId;
    
    // In a real implementation, we would fetch the analysis results from a database
    // For the MVP, we'll return mock data
    
    // Mock analysis results based on document ID
    const mockResults = {
      documentId,
      documentName: "Groundwater Monitoring Report Q1 2025.pdf",
      uploadDate: "April 16, 2025",
      analysisDate: "April 16, 2025",
      status: "Completed",
      discrepancies: [
        {
          id: 1,
          type: "Numerical Discrepancy",
          description: "The text on page 12 states the pH level as 7.2, but Table 3 shows it as 7.5.",
          location: "Page 12, Paragraph 3 & Table 3",
          severity: "Medium",
        },
        {
          id: 2,
          type: "Numerical Discrepancy",
          description: "The groundwater level is reported as 45.3 feet in the text on page 8, but Figure 2 shows it as 45.8 feet.",
          location: "Page 8, Section 4.2 & Figure 2",
          severity: "Low",
        },
        {
          id: 3,
          type: "Numerical Discrepancy",
          description: "The concentration of dissolved solids is listed as 320 mg/L in the executive summary, but Table 5 shows 350 mg/L.",
          location: "Page 2, Executive Summary & Page 18, Table 5",
          severity: "High",
        },
      ],
      regulatoryGaps: [
        {
          id: 1,
          regulation: "EPA Groundwater Monitoring Requirements",
          description: "The report is missing required information on sampling methodology as specified in Section 3.2 of EPA guidelines.",
          recommendation: "Add a detailed description of the sampling methodology used, including equipment and procedures.",
          severity: "High",
        },
        {
          id: 2,
          regulation: "State Environmental Quality Standards",
          description: "The report does not address the new requirement for PFAS monitoring that became effective January 2025.",
          recommendation: "Include PFAS monitoring results or provide justification for exclusion.",
          severity: "Medium",
        },
      ],
      completenessIssues: [
        {
          id: 1,
          description: "The Quality Assurance section is incomplete, missing information on laboratory certifications.",
          recommendation: "Add laboratory certification details to the Quality Assurance section.",
          severity: "Medium",
        },
        {
          id: 2,
          description: "Appendix B referenced in the text is not included in the document.",
          recommendation: "Include Appendix B with the referenced data tables.",
          severity: "Low",
        },
      ]
    };
    
    return NextResponse.json(mockResults);
    
  } catch (error) {
    console.error('Error fetching analysis results:', error);
    return NextResponse.json(
      { error: 'Error fetching analysis results' },
      { status: 500 }
    );
  }
}
