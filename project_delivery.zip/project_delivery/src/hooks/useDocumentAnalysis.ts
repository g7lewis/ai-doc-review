// Component to connect the frontend with the AI analysis backend
// This handles the client-side integration with the document analyzer

import { useState } from 'react';

// Interface for analysis options
interface AnalysisOptions {
  numericalDiscrepancy: boolean;
  regulatoryCompliance: boolean;
  contentCompleteness: boolean;
}

// Interface for analysis result
interface AnalysisResult {
  success: boolean;
  documentId: string;
  message: string;
  status: string;
  analysisDate: string;
}

/**
 * Hook for document analysis functionality
 * @returns Analysis functions and state
 */
export function useDocumentAnalysis() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  /**
   * Analyze a document with the specified options
   * @param documentId ID of the document to analyze
   * @param options Analysis options
   * @returns Analysis result
   */
  const analyzeDocument = async (
    documentId: string,
    options: AnalysisOptions
  ): Promise<AnalysisResult> => {
    setIsAnalyzing(true);
    setError(null);
    
    try {
      const response = await fetch(`/api/analyze/${documentId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(options),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to analyze document');
      }
      
      const result = await response.json();
      setAnalysisResult(result);
      return result;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred';
      setError(errorMessage);
      throw err;
    } finally {
      setIsAnalyzing(false);
    }
  };
  
  /**
   * Get analysis results for a document
   * @param documentId ID of the document
   * @returns Analysis results
   */
  const getAnalysisResults = async (documentId: string) => {
    try {
      const response = await fetch(`/api/analysis/${documentId}`);
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to get analysis results');
      }
      
      return await response.json();
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred';
      setError(errorMessage);
      throw err;
    }
  };
  
  return {
    analyzeDocument,
    getAnalysisResults,
    isAnalyzing,
    analysisResult,
    error,
  };
}

/**
 * Hook for document upload and analysis
 * @returns Upload and analysis functions and state
 */
export function useDocumentUpload() {
  const [isUploading, setIsUploading] = useState(false);
  const [uploadResult, setUploadResult] = useState<any | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const { analyzeDocument, isAnalyzing } = useDocumentAnalysis();
  
  /**
   * Upload and analyze a document
   * @param file File to upload
   * @param documentType Type of document
   * @param analysisOptions Analysis options
   * @returns Upload and analysis result
   */
  const uploadAndAnalyzeDocument = async (
    file: File,
    documentType: string,
    analysisOptions: AnalysisOptions
  ) => {
    setIsUploading(true);
    setUploadError(null);
    
    try {
      // Create form data for upload
      const formData = new FormData();
      formData.append('file', file);
      formData.append('documentType', documentType);
      formData.append('numericalDiscrepancy', analysisOptions.numericalDiscrepancy.toString());
      formData.append('regulatoryCompliance', analysisOptions.regulatoryCompliance.toString());
      formData.append('contentCompleteness', analysisOptions.contentCompleteness.toString());
      
      // Upload document
      const uploadResponse = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });
      
      if (!uploadResponse.ok) {
        const errorData = await uploadResponse.json();
        throw new Error(errorData.error || 'Failed to upload document');
      }
      
      const uploadData = await uploadResponse.json();
      setUploadResult(uploadData);
      
      // Analyze document
      if (uploadData.success && uploadData.documentId) {
        await analyzeDocument(uploadData.documentId, analysisOptions);
      }
      
      return uploadData;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred';
      setUploadError(errorMessage);
      throw err;
    } finally {
      setIsUploading(false);
    }
  };
  
  return {
    uploadAndAnalyzeDocument,
    isUploading,
    isProcessing: isUploading || isAnalyzing,
    uploadResult,
    uploadError,
  };
}
