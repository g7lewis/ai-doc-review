// End-to-end test script for the document review tool
// This script tests the frontend and backend integration

import { test, expect } from '@playwright/test';

// Test the home page
test('home page loads correctly', async ({ page }) => {
  await page.goto('/');
  
  // Check that the page title is correct
  await expect(page).toHaveTitle(/Document Review Tool/);
  
  // Check that the main heading is present
  const heading = page.locator('h1:has-text("AI-Powered Document Review")');
  await expect(heading).toBeVisible();
  
  // Check that the navigation links are present
  await expect(page.locator('a:has-text("Home")')).toBeVisible();
  await expect(page.locator('a:has-text("Upload")')).toBeVisible();
  await expect(page.locator('a:has-text("Dashboard")')).toBeVisible();
  
  // Check that the feature sections are present
  await expect(page.locator('dt:has-text("Numerical Discrepancy Detection")')).toBeVisible();
  await expect(page.locator('dt:has-text("Regulatory Compliance Checking")')).toBeVisible();
  await expect(page.locator('dt:has-text("Multi-Format Support")')).toBeVisible();
  await expect(page.locator('dt:has-text("Detailed Analysis Reports")')).toBeVisible();
});

// Test the upload page
test('upload page loads correctly', async ({ page }) => {
  await page.goto('/upload');
  
  // Check that the page title is correct
  await expect(page.locator('h1:has-text("Upload Document")')).toBeVisible();
  
  // Check that the document type dropdown is present
  await expect(page.locator('#document-type')).toBeVisible();
  
  // Check that the file upload area is present
  await expect(page.locator('label:has-text("Upload a file")')).toBeVisible();
  
  // Check that the analysis options are present
  await expect(page.locator('#numerical-discrepancy')).toBeVisible();
  await expect(page.locator('#regulatory-compliance')).toBeVisible();
  await expect(page.locator('#content-completeness')).toBeVisible();
  
  // Check that the submit button is present but disabled (no file selected)
  const submitButton = page.locator('button:has-text("Upload and Analyze")');
  await expect(submitButton).toBeVisible();
  await expect(submitButton).toBeDisabled();
});

// Test the dashboard page
test('dashboard page loads correctly', async ({ page }) => {
  await page.goto('/dashboard');
  
  // Check that the page title is correct
  await expect(page.locator('h1:has-text("Dashboard")')).toBeVisible();
  
  // Check that the document list is present
  await expect(page.locator('h2:has-text("Your Documents")')).toBeVisible();
  
  // Check that the table headers are present
  await expect(page.locator('th:has-text("Document Name")')).toBeVisible();
  await expect(page.locator('th:has-text("Type")')).toBeVisible();
  await expect(page.locator('th:has-text("Upload Date")')).toBeVisible();
  await expect(page.locator('th:has-text("Status")')).toBeVisible();
  await expect(page.locator('th:has-text("Issues Found")')).toBeVisible();
  
  // Check that the mock documents are present
  await expect(page.locator('td:has-text("Groundwater Monitoring Report Q1 2025.pdf")')).toBeVisible();
  
  // Check that the analysis summary is present
  await expect(page.locator('h2:has-text("Analysis Summary")')).toBeVisible();
  await expect(page.locator('dt:has-text("Total Documents")')).toBeVisible();
  await expect(page.locator('dt:has-text("Total Issues Found")')).toBeVisible();
  await expect(page.locator('dt:has-text("High Severity Issues")')).toBeVisible();
});

// Test the results page
test('results page loads correctly', async ({ page }) => {
  await page.goto('/results');
  
  // Check that the page title is correct
  await expect(page.locator('h1:has-text("Analysis Results")')).toBeVisible();
  
  // Check that the document information is present
  await expect(page.locator('h3:has-text("Document Information")')).toBeVisible();
  await expect(page.locator('dt:has-text("Document name")')).toBeVisible();
  await expect(page.locator('dt:has-text("Upload date")')).toBeVisible();
  await expect(page.locator('dt:has-text("Analysis date")')).toBeVisible();
  await expect(page.locator('dt:has-text("Status")')).toBeVisible();
  
  // Check that the tabs are present
  await expect(page.locator('button:has-text("Numerical Discrepancies")')).toBeVisible();
  await expect(page.locator('button:has-text("Regulatory Gaps")')).toBeVisible();
  await expect(page.locator('button:has-text("Completeness Issues")')).toBeVisible();
  
  // Check that the numerical discrepancies are visible by default
  await expect(page.locator('h3:has-text("Numerical Discrepancies")')).toBeVisible();
  
  // Click on the Regulatory Gaps tab and check that the content changes
  await page.locator('button:has-text("Regulatory Gaps")').click();
  await expect(page.locator('h3:has-text("Regulatory Gaps")')).toBeVisible();
  
  // Click on the Completeness Issues tab and check that the content changes
  await page.locator('button:has-text("Completeness Issues")').click();
  await expect(page.locator('h3:has-text("Completeness Issues")')).toBeVisible();
});

// Test the API endpoints
test('API endpoints return correct responses', async ({ request }) => {
  // Test the documents endpoint
  const documentsResponse = await request.get('/api/documents');
  expect(documentsResponse.ok()).toBeTruthy();
  const documents = await documentsResponse.json();
  expect(Array.isArray(documents)).toBeTruthy();
  expect(documents.length).toBeGreaterThan(0);
  
  // Test the document metadata endpoint
  const documentId = documents[0].id;
  const documentResponse = await request.get(`/api/documents/${documentId}`);
  expect(documentResponse.ok()).toBeTruthy();
  const document = await documentResponse.json();
  expect(document.id).toBe(documentId);
  
  // Test the analysis results endpoint
  const analysisResponse = await request.get(`/api/analysis/${documentId}`);
  expect(analysisResponse.ok()).toBeTruthy();
  const analysis = await analysisResponse.json();
  expect(analysis.documentId).toBe(documentId);
  expect(analysis.discrepancies).toBeDefined();
  expect(analysis.regulatoryGaps).toBeDefined();
  expect(analysis.completenessIssues).toBeDefined();
});

// Test file upload and analysis (mock)
test('file upload and analysis flow', async ({ page }) => {
  await page.goto('/upload');
  
  // Create a mock file for upload
  await page.setInputFiles('input[type="file"]', {
    name: 'test-document.pdf',
    mimeType: 'application/pdf',
    buffer: Buffer.from('Mock PDF content')
  });
  
  // Check that the file name is displayed
  await expect(page.locator('text=test-document.pdf')).toBeVisible();
  
  // Check that the submit button is now enabled
  const submitButton = page.locator('button:has-text("Upload and Analyze")');
  await expect(submitButton).toBeEnabled();
  
  // Click the submit button
  // Note: In a real test, we would intercept the fetch requests and mock the responses
  // For this MVP test, we'll just check that the button can be clicked
  await submitButton.click();
  
  // In a real implementation with proper mocking, we would check for the success message
  // await expect(page.locator('text=Upload successful')).toBeVisible();
});
