// Test script for the document review tool
// This script tests the main functionality of the application

import fs from 'fs';
import path from 'path';
import { DocumentProcessor } from '../lib/documentProcessor';
import { DocumentAnalyzer } from '../lib/documentAnalyzer';

// Test configuration
const TEST_DIR = path.join(process.cwd(), 'test');
const UPLOADS_DIR = path.join(process.cwd(), 'uploads');
const TEST_FILES = {
  pdf: 'test-document.pdf',
  docx: 'test-document.docx',
  xlsx: 'test-document.xlsx'
};

// Ensure test directories exist
if (!fs.existsSync(TEST_DIR)) {
  fs.mkdirSync(TEST_DIR, { recursive: true });
}

if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

// Create test files if they don't exist
function createTestFiles() {
  console.log('Creating test files...');
  
  // Create a simple PDF-like test file
  if (!fs.existsSync(path.join(TEST_DIR, TEST_FILES.pdf))) {
    fs.writeFileSync(
      path.join(TEST_DIR, TEST_FILES.pdf),
      '%PDF-1.5\nThis is a mock PDF file for testing purposes.\n%%EOF'
    );
    console.log(`Created ${TEST_FILES.pdf}`);
  }
  
  // Create a simple DOCX-like test file
  if (!fs.existsSync(path.join(TEST_DIR, TEST_FILES.docx))) {
    fs.writeFileSync(
      path.join(TEST_DIR, TEST_FILES.docx),
      'This is a mock DOCX file for testing purposes.'
    );
    console.log(`Created ${TEST_FILES.docx}`);
  }
  
  // Create a simple XLSX-like test file
  if (!fs.existsSync(path.join(TEST_DIR, TEST_FILES.xlsx))) {
    fs.writeFileSync(
      path.join(TEST_DIR, TEST_FILES.xlsx),
      'This is a mock XLSX file for testing purposes.'
    );
    console.log(`Created ${TEST_FILES.xlsx}`);
  }
}

// Test document processing
async function testDocumentProcessing() {
  console.log('\n=== Testing Document Processing ===');
  
  try {
    // Test PDF processing
    console.log('\nTesting PDF processing...');
    const pdfPath = path.join(TEST_DIR, TEST_FILES.pdf);
    const pdfContent = await DocumentProcessor.processDocument(pdfPath);
    console.log('PDF processing successful');
    console.log('Extracted metadata:', pdfContent.metadata);
    console.log('Number of tables:', pdfContent.tables.length);
    
    // Test Word processing
    console.log('\nTesting Word processing...');
    const docxPath = path.join(TEST_DIR, TEST_FILES.docx);
    const docxContent = await DocumentProcessor.processDocument(docxPath);
    console.log('Word processing successful');
    console.log('Extracted metadata:', docxContent.metadata);
    console.log('Number of tables:', docxContent.tables.length);
    
    // Test Excel processing
    console.log('\nTesting Excel processing...');
    const xlsxPath = path.join(TEST_DIR, TEST_FILES.xlsx);
    const xlsxContent = await DocumentProcessor.processDocument(xlsxPath);
    console.log('Excel processing successful');
    console.log('Extracted metadata:', xlsxContent.metadata);
    console.log('Number of tables:', xlsxContent.tables.length);
    
    return true;
  } catch (error) {
    console.error('Document processing test failed:', error);
    return false;
  }
}

// Test document analysis
async function testDocumentAnalysis() {
  console.log('\n=== Testing Document Analysis ===');
  
  try {
    // Test analysis with all options enabled
    console.log('\nTesting full analysis...');
    const pdfPath = path.join(TEST_DIR, TEST_FILES.pdf);
    const analysisOptions = {
      numericalDiscrepancy: true,
      regulatoryCompliance: true,
      contentCompleteness: true
    };
    
    const analysisResults = await DocumentAnalyzer.analyzeDocument(pdfPath, analysisOptions);
    
    console.log('Analysis successful');
    console.log('Numerical discrepancies found:', analysisResults.discrepancies.length);
    console.log('Regulatory gaps found:', analysisResults.regulatoryGaps.length);
    console.log('Completeness issues found:', analysisResults.completenessIssues.length);
    
    // Test analysis with only numerical discrepancy detection
    console.log('\nTesting numerical discrepancy detection only...');
    const numericalOptions = {
      numericalDiscrepancy: true,
      regulatoryCompliance: false,
      contentCompleteness: false
    };
    
    const numericalResults = await DocumentAnalyzer.analyzeDocument(pdfPath, numericalOptions);
    
    console.log('Analysis successful');
    console.log('Numerical discrepancies found:', numericalResults.discrepancies.length);
    console.log('Regulatory gaps found:', numericalResults.regulatoryGaps.length);
    console.log('Completeness issues found:', numericalResults.completenessIssues.length);
    
    return true;
  } catch (error) {
    console.error('Document analysis test failed:', error);
    return false;
  }
}

// Test API endpoints
async function testApiEndpoints() {
  console.log('\n=== Testing API Endpoints ===');
  
  try {
    // Note: In a real test environment, we would use a testing framework like Jest
    // and libraries like supertest to test the API endpoints.
    // For this MVP, we'll just log the endpoints that would be tested.
    
    console.log('\nEndpoints to test:');
    console.log('- POST /api/upload - Document upload');
    console.log('- POST /api/analyze/[documentId] - Document analysis');
    console.log('- GET /api/analysis/[documentId] - Get analysis results');
    console.log('- GET /api/documents - List documents');
    console.log('- GET /api/documents/[documentId] - Get document metadata');
    console.log('- GET /api/documents/[documentId]/file - Serve document file');
    
    console.log('\nAPI endpoint testing would be implemented with Jest and supertest in a production environment.');
    
    return true;
  } catch (error) {
    console.error('API endpoint test failed:', error);
    return false;
  }
}

// Run all tests
async function runTests() {
  console.log('=== Document Review Tool Tests ===');
  
  // Create test files
  createTestFiles();
  
  // Run tests
  const processingResult = await testDocumentProcessing();
  const analysisResult = await testDocumentAnalysis();
  const apiResult = await testApiEndpoints();
  
  // Report results
  console.log('\n=== Test Results ===');
  console.log('Document Processing:', processingResult ? 'PASSED' : 'FAILED');
  console.log('Document Analysis:', analysisResult ? 'PASSED' : 'FAILED');
  console.log('API Endpoints:', apiResult ? 'PASSED' : 'FAILED');
  
  const overallResult = processingResult && analysisResult && apiResult;
  console.log('\nOverall Test Result:', overallResult ? 'PASSED' : 'FAILED');
  
  return overallResult;
}

// Execute tests
runTests()
  .then(result => {
    console.log('\nTests completed.');
    process.exit(result ? 0 : 1);
  })
  .catch(error => {
    console.error('Error running tests:', error);
    process.exit(1);
  });
