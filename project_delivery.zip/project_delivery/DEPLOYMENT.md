# Document Review Tool Deployment Guide

This guide provides instructions for deploying the Document Review Tool to Cloudflare Pages.

## Prerequisites

Before deploying, ensure you have the following:

1. A Cloudflare account
2. Node.js and npm installed
3. Wrangler CLI installed (`npm install -g wrangler`)
4. Logged in to Wrangler (`wrangler login`)

## Deployment Steps

### 1. Build the Application

First, build the Next.js application:

```bash
cd /home/ubuntu/document-review-tool/document-review-app
npm install
npm run build
```

### 2. Configure Deployment Settings

The `wrangler.toml` file contains the configuration for deploying to Cloudflare Pages. Review and update the settings as needed:

- `name`: The name of your application (determines the URL)
- `compatibility_date`: The compatibility date for Cloudflare Workers
- Database and storage settings (uncomment and configure as needed)

### 3. Deploy to Cloudflare Pages

Deploy the application using Wrangler:

```bash
wrangler pages publish .next --project-name document-review-tool
```

This will deploy the application to Cloudflare Pages and provide a URL where the application can be accessed.

### 4. Set Up Environment Variables

If your application requires environment variables (e.g., API keys, database connections), set them up in the Cloudflare Pages dashboard:

1. Go to the Cloudflare Pages dashboard
2. Select your project (document-review-tool)
3. Go to Settings > Environment variables
4. Add the required environment variables

### 5. Configure Custom Domain (Optional)

To use a custom domain instead of the default `document-review-tool.pages.dev`:

1. Go to the Cloudflare Pages dashboard
2. Select your project
3. Go to Custom domains
4. Add your custom domain and follow the instructions to set up DNS

## Updating the Application

To update the application after making changes:

1. Make your changes to the codebase
2. Build the application: `npm run build`
3. Deploy the updated application: `wrangler pages publish .next --project-name document-review-tool`

## Troubleshooting

If you encounter issues during deployment:

1. Check the Wrangler logs for error messages
2. Verify that all dependencies are installed
3. Ensure that the build process completed successfully
4. Check the Cloudflare Pages dashboard for deployment status and logs

## Database Setup (When Enabled)

If you uncomment the D1 database configuration in `wrangler.toml`:

1. Create the database: `wrangler d1 create document_review_db`
2. Apply migrations: `wrangler d1 migrations apply DB --local`
3. Update the database ID in `wrangler.toml`

## Storage Setup (When Enabled)

If you uncomment the R2 storage configuration in `wrangler.toml`:

1. Create the storage bucket: `wrangler r2 bucket create document-review-storage`
2. Update the bucket name in `wrangler.toml` if needed
