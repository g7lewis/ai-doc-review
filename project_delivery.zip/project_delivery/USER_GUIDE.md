# Document Review Tool - User Guide

## Introduction

The Document Review Tool is an AI-powered application designed to help you review business and technical documents for quality assurance and quality control purposes. This guide will walk you through how to use the application effectively.

## Getting Started

### Accessing the Application

After deployment, the application will be available at the URL provided by Cloudflare Pages (typically `https://document-review-tool.pages.dev` unless a custom domain is configured).

### Navigation

The application has four main sections:
- **Home**: Overview of the tool's features
- **Upload**: Where you can upload documents for analysis
- **Dashboard**: View and manage your uploaded documents
- **Results**: View detailed analysis results for each document

## Uploading Documents

1. Navigate to the **Upload** page by clicking "Upload" in the navigation bar or the "Upload Document" button on the home page.

2. Select the document type from the dropdown menu (e.g., Environmental Report, Groundwater Monitoring Report, Technical Specification).

3. Upload your document by either:
   - Clicking "Upload a file" and selecting a file from your computer
   - Dragging and dropping a file onto the upload area

4. Select the analysis options you want to perform:
   - **Numerical Discrepancy Detection**: Identifies inconsistencies between numbers in text and tables
   - **Regulatory Compliance Checking**: Compares document content against regulatory requirements
   - **Content Completeness Check**: Verifies that all required sections and information are present

5. Click "Upload and Analyze" to start the analysis process.

6. Wait for the analysis to complete. You will be redirected to the results page when finished.

## Supported File Types

The tool supports the following file formats:
- PDF (`.pdf`)
- Microsoft Word (`.docx`, `.doc`)
- Microsoft Excel (`.xlsx`, `.xls`)

Maximum file size: 20MB

## Viewing Results

### Results Page

The results page displays the analysis findings organized into three tabs:

1. **Numerical Discrepancies**: Shows inconsistencies between numbers in text and tables
   - Each discrepancy includes a description, location, and severity level

2. **Regulatory Gaps**: Shows areas where the document may not meet regulatory requirements
   - Each gap includes the relevant regulation, description, recommendation, and severity level

3. **Completeness Issues**: Shows missing or incomplete sections in the document
   - Each issue includes a description, recommendation, and severity level

### Understanding Severity Levels

Issues are categorized by severity:
- **Low** (Blue): Minor issues that should be addressed but don't significantly impact document quality
- **Medium** (Yellow): Important issues that should be addressed before finalizing the document
- **High** (Red): Critical issues that must be addressed immediately

## Dashboard

The dashboard provides an overview of all your uploaded documents and their analysis status.

### Document List

The document list shows:
- Document name
- Document type
- Upload date
- Analysis status
- Number of issues found
- Link to view detailed results

### Analysis Summary

The dashboard also displays summary statistics:
- Total number of documents
- Total issues found
- Number of high severity issues

## Best Practices

For the best results when using the Document Review Tool:

1. **Prepare your documents properly**:
   - Ensure tables are properly formatted
   - Use consistent formatting for numerical values
   - Include all referenced appendices and attachments

2. **Review all analysis results**:
   - Check each tab for different types of issues
   - Prioritize high severity issues
   - Implement the recommended fixes

3. **Re-analyze after making changes**:
   - Upload the revised document for a new analysis
   - Compare results to verify improvements

## Troubleshooting

### Common Issues

1. **File upload fails**:
   - Ensure the file is in a supported format (PDF, Word, Excel)
   - Check that the file size is under 20MB
   - Try a different browser if problems persist

2. **Analysis takes too long**:
   - Large or complex documents may take longer to analyze
   - Check your internet connection
   - Refresh the page if it seems stuck

3. **Missing analysis results**:
   - Ensure you've selected the appropriate analysis options during upload
   - Some document types may not have certain types of issues

### Getting Help

If you encounter any issues not covered in this guide, please contact the support team for assistance.
